# Set up your GitHub in 20–30 minutes

1. Sign in at https://github.com/meghsraj-hue.
2. Create a **public** repository named exactly `meghsraj-hue`. Check **Add a README**. Edit README and replace its content with `meghsraj-hue/README.md` from this pack.
3. Create a public repository `aws-cloud-devops-projects`; upload the contents of the matching folder, including its README and `projects` directory.
4. Create public repositories `enterprise-infrastructure-case-studies` and `technical-program-management`; upload each matching folder's contents.
5. Open your GitHub profile, choose **Customize your pins**, and pin these three repositories.
6. Click each link in your profile README to confirm it works.
7. Before job applications, add `https://github.com/meghsraj-hue` to your resume and LinkedIn.

**Important:** The project report supports the project summaries, but does not prove that runnable source code or screenshots are present. Add actual artifacts only when you have checked and sanitized them. Do not publish AWS credentials, tokens, personal data or ICICI internal information.
