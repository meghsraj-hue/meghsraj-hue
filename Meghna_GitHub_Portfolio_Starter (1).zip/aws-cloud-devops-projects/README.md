# AWS & DevOps — 20 Hands-on Projects

These are hands-on cloud and DevOps implementations, not claims of production deployment at a former employer. Technical details below are summarized from my project report. Add verified scripts, diagrams and screenshots before presenting a repository as containing those artifacts.

## Project index

1. [Deploying EC2 Instances with Terraform and a Custom VPC](projects/01-deploying-ec2-instances-with-terraform-and-a-custom-vpc.md)
2. [Implementing CI CD for a Full Stack Application](projects/02-implementing-ci-cd-for-a-full-stack-application.md)
3. [Deploying a Kubernetes Pod Using Amazon EKS](projects/03-deploying-a-kubernetes-pod-using-amazon-eks.md)
4. [AWS End to End Infrastructure Project](projects/04-aws-end-to-end-infrastructure-project.md)
5. [Scaling an EBS Volume for a Linux Virtual Machine](projects/05-scaling-an-ebs-volume-for-a-linux-virtual-machine.md)
6. [Deploying a Static Website with Amazon S3](projects/06-deploying-a-static-website-with-amazon-s3.md)
7. [Customizing an EC2 Instance as a Web Server](projects/07-customizing-an-ec2-instance-as-a-web-server.md)
8. [Deploying MySQL on Amazon RDS](projects/08-deploying-mysql-on-amazon-rds.md)
9. [Creating IAM Groups Users and Policies](projects/09-creating-iam-groups-users-and-policies.md)
10. [Using AWS Lambda to Copy Objects Between S3 Buckets](projects/10-using-aws-lambda-to-copy-objects-between-s3-buckets.md)
11. [Creating an Alarm in Amazon CloudWatch](projects/11-creating-an-alarm-in-amazon-cloudwatch.md)
12. [Monitoring an ECS Cluster with CloudWatch Container Insights](projects/12-monitoring-an-ecs-cluster-with-cloudwatch-container-insights.md)
13. [Jenkins Backup and Restore Using Amazon S3](projects/13-jenkins-backup-and-restore-using-amazon-s3.md)
14. [AWS Automation with Terraform and Ansible](projects/14-aws-automation-with-terraform-and-ansible.md)
15. [Python Application Development with Git Version Control](projects/15-python-application-development-with-git-version-control.md)
16. [Automated AWS Deployment with GitHub Actions](projects/16-automated-aws-deployment-with-github-actions.md)
17. [Automating Spring Boot Application Deployment on AWS](projects/17-automating-spring-boot-application-deployment-on-aws.md)
18. [Highly Available Load Balanced Architecture Configured Through CLI](projects/18-highly-available-load-balanced-architecture-configured-through-cli.md)
19. [Capstone Spring Boot Banking Microservice on AWS with Jenkins Docker and Ansible](projects/19-capstone-spring-boot-banking-microservice-on-aws-with-jenkins-docker-and-ansible.md)
20. [Capstone Microservices Delivery with CodePipeline and ECS Fargate](projects/20-capstone-microservices-delivery-with-codepipeline-and-ecs-fargate.md)
