# Project 02: Implementing CI CD for a Full Stack Application

**Project type:** Hands-on cloud/DevOps implementation

## Project summary

I implemented a CI/CD workflow for a full stack application, connecting application source changes with build and deployment activities across the frontend and backend. I connected the application repository to the pipeline. I defined the frontend and backend build steps, dependency installation, available tests and deployment stages. I configured the target environment and application settings. I ran the workflow and validated that the user interface could communicate with the backend. I preserved build logs and the deployed application output. The project output consisted of a full stack deployment workflow connecting source changes to application delivery. The intended output was deployable frontend and backend components and an accessible application. This approach enables more consistent releases and earlier visibility of build failures. The business opportunity is shorter feedback cycles for product changes and less manual coordination during deployment. A product team can use this delivery pattern when releasing changes that affect both the user interface and application services. Shared pipeline visibility helps developers and operations teams locate failures before completing a release.

## Evidence to add

- [ ] Sanitized architecture diagram
- [ ] Original configuration/scripts (where available)
- [ ] Screenshots with account IDs, secrets and IPs removed
- [ ] Validation steps and outcome
- [ ] Lessons learned

## Confidentiality

Do not upload credentials, access keys, real customer data, internal company files or unredacted cloud account information.
