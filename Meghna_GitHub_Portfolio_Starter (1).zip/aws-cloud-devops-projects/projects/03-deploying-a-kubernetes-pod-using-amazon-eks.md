# Project 03: Deploying a Kubernetes Pod Using Amazon EKS

**Project type:** Hands-on cloud/DevOps implementation

## Project summary

I deployed a Kubernetes pod using Amazon EKS, working with the cluster access configuration and workload definition needed to run a containerized application. I configured access to the EKS cluster and the kubectl context. I defined the pod manifest with the required image, ports and runtime settings. I applied the manifest and inspected the pod status, events and logs. I validated the running workload using the access method configured in the project. I kept the manifest as the reproducible workload definition. The project output consisted of a Kubernetes pod running on an EKS cluster, supported by a manifest and runtime status. A pod deployment alone does not establish an application scaling or recovery policy. This work builds a foundation for Kubernetes based application operations. The business opportunity is consistent workload packaging and deployment; broader availability benefits require additional controllers, replicas and operational validation. The deployed pod provides a starting point for moving a containerized service to Kubernetes. A broader service deployment can build on this foundation by adding controllers, health probes, replicas and an appropriate access path.

## Evidence to add

- [ ] Sanitized architecture diagram
- [ ] Original configuration/scripts (where available)
- [ ] Screenshots with account IDs, secrets and IPs removed
- [ ] Validation steps and outcome
- [ ] Lessons learned

## Confidentiality

Do not upload credentials, access keys, real customer data, internal company files or unredacted cloud account information.
