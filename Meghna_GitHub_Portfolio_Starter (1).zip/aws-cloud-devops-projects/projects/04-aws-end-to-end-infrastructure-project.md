# Project 04: AWS End to End Infrastructure Project

**Project type:** Hands-on cloud/DevOps implementation

## Project summary

I completed an end to end AWS infrastructure project, bringing the infrastructure components together into a working environment and checking their integration. I identified the compute, networking, storage, access and monitoring components included in the project. I configured their dependencies and allowed communication paths. I deployed the workload, checked each component separately and then validated the complete user request path. I documented the resource relationships and operational checks needed to reproduce the setup. The project output consisted of An integrated AWS environment with a working request path across the components actually deployed. The architecture diagram and resource inventory capture the final scope. This work demonstrates integration across infrastructure layers. For Flexytie, the business opportunity is a documented environment that supports onboarding, troubleshooting and future changes with less reliance on individual knowledge. An integrated environment supports application onboarding and infrastructure handover. The documented relationships between components help a new team member understand where a user request travels and where a failure may occur.

## Evidence to add

- [ ] Sanitized architecture diagram
- [ ] Original configuration/scripts (where available)
- [ ] Screenshots with account IDs, secrets and IPs removed
- [ ] Validation steps and outcome
- [ ] Lessons learned

## Confidentiality

Do not upload credentials, access keys, real customer data, internal company files or unredacted cloud account information.
