# Project 06: Deploying a Static Website with Amazon S3

**Project type:** Hands-on cloud/DevOps implementation

## Project summary

I deployed a static website using Amazon S3, preparing the website content and configuring the bucket based hosting workflow. I prepared the website assets and uploaded them to the bucket. I configured the hosting option used in the project, index and error documents, and the required object access. I tested the website endpoint, navigation and asset loading. I documented the access configuration and update process. The project output consisted of a static website accessible through the configured endpoint, with its pages and assets stored in S3. This approach provides a simple publication path for informational pages, demonstrations or product content. The business opportunity is reducing web server administration for static content; actual hosting savings depend on traffic and the delivery configuration. The hosting pattern can support informational websites, project demonstrations and static product pages. Content changes can be published by updating assets without maintaining a continuously running application server.

## Evidence to add

- [ ] Sanitized architecture diagram
- [ ] Original configuration/scripts (where available)
- [ ] Screenshots with account IDs, secrets and IPs removed
- [ ] Validation steps and outcome
- [ ] Lessons learned

## Confidentiality

Do not upload credentials, access keys, real customer data, internal company files or unredacted cloud account information.
