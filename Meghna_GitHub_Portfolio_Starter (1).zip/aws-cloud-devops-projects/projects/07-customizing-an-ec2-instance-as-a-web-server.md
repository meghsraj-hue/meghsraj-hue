# Project 07: Customizing an EC2 Instance as a Web Server

**Project type:** Hands-on cloud/DevOps implementation

## Project summary

I customized an EC2 instance to function as a web server, connecting operating system setup, web service configuration and network access. I launched the instance, installed the chosen web server and configured the document root. I added the project content, configured the service and permitted only the required network access. I verified service status and tested the web response. I recorded installation and configuration steps so a replacement instance can be prepared consistently. The project output consisted of An EC2 hosted web server responding on the configured address and port, with project content displayed in a browser. This approach enables application or website hosting on configurable compute infrastructure. For Flexytie, the business opportunity is a repeatable server setup and a clear path for diagnosing service or connectivity failures. A configured web instance can support a web application demonstration or a server hosted website. The setup also provides a concrete environment for learning service management and diagnosing connectivity problems.

## Evidence to add

- [ ] Sanitized architecture diagram
- [ ] Original configuration/scripts (where available)
- [ ] Screenshots with account IDs, secrets and IPs removed
- [ ] Validation steps and outcome
- [ ] Lessons learned

## Confidentiality

Do not upload credentials, access keys, real customer data, internal company files or unredacted cloud account information.
