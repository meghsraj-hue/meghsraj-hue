# Project 09: Creating IAM Groups Users and Policies

**Project type:** Hands-on cloud/DevOps implementation

## Project summary

I created and configured AWS IAM users, groups and policies, organizing access permissions around the responsibilities represented in the project. I created the identities and groups included in the project. I configured the policies to match to their responsibilities and resource scope. I assigned users to groups and tested representative allowed and denied actions. I documented the relationship between users, groups and permissions. I kept access keys and other credentials out of the report. The project output consisted of An IAM access structure with users assigned to groups and policies governing their permitted actions. This approach enables controlled access and clearer separation of responsibilities. For Flexytie, the business opportunity is simpler access administration and lower exposure from excessive permissions, provided policy scope has been reviewed. Group based permissions can support onboarding and consistent access assignments. A documented policy structure makes it easier to understand access ownership and review permissions when responsibilities change.

## Evidence to add

- [ ] Sanitized architecture diagram
- [ ] Original configuration/scripts (where available)
- [ ] Screenshots with account IDs, secrets and IPs removed
- [ ] Validation steps and outcome
- [ ] Lessons learned

## Confidentiality

Do not upload credentials, access keys, real customer data, internal company files or unredacted cloud account information.
