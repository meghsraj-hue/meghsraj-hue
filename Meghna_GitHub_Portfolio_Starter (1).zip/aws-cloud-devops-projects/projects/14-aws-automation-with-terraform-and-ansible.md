# Project 14: AWS Automation with Terraform and Ansible

**Project type:** Hands-on cloud/DevOps implementation

## Project summary

I combined Terraform and Ansible in an AWS automation project, linking infrastructure provisioning with server configuration. I defined AWS resources in Terraform and provisioned them after reviewing the plan. I used the resulting host details in the Ansible inventory. I configured connectivity and ran playbooks to install packages or apply the required server settings. I validated the configured server. The project output consisted of Infrastructure configuration and Ansible playbooks that create and configure the target environment in a repeatable sequence. This approach enables consistent environment setup across infrastructure and operating system layers. For Flexytie, the business opportunity is less repetitive setup work and clearer recovery or recreation procedures. The automation can support repeatable developer or application environments. Keeping resource definitions and server configuration in code simplifies review and gives the team a clearer recreation path.

## Evidence to add

- [ ] Sanitized architecture diagram
- [ ] Original configuration/scripts (where available)
- [ ] Screenshots with account IDs, secrets and IPs removed
- [ ] Validation steps and outcome
- [ ] Lessons learned

## Confidentiality

Do not upload credentials, access keys, real customer data, internal company files or unredacted cloud account information.
