# Project 15: Python Application Development with Git Version Control

**Project type:** Hands-on cloud/DevOps implementation

## Project summary

I created a Python application and managed its source using Git, applying a version control workflow to application development. I created the Python application and ran it to verify the intended behavior. I initialized a Git repository, staged source files and recorded meaningful commits. I used the branch and merge workflow demonstrated in the project and inspected the history. I documented dependencies and the command needed to run the application so another developer can reproduce the output. The project output consisted of a runnable Python application with source history maintained in Git. The deliverables are the application source, commit history and execution instructions. This approach enables controlled changes and easier collaboration around application code. The business opportunity is traceability when investigating defects and simpler handover to other contributors. Git history alone does not prove automated testing or deployment. The repository can support collaboration and controlled application changes. Commit history provides context for reviewing changes, investigating regressions and handing the application to another contributor.

## Evidence to add

- [ ] Sanitized architecture diagram
- [ ] Original configuration/scripts (where available)
- [ ] Screenshots with account IDs, secrets and IPs removed
- [ ] Validation steps and outcome
- [ ] Lessons learned

## Confidentiality

Do not upload credentials, access keys, real customer data, internal company files or unredacted cloud account information.
