# Project 16: Automated AWS Deployment with GitHub Actions

**Project type:** Hands-on cloud/DevOps implementation

## Project summary

I implemented automated deployment to AWS using GitHub Actions, defining the workflow that connects repository activity with deployment execution. I created the workflow file with the required trigger and jobs. I configured AWS authentication using the method implemented and limited permissions to the deployment scope. I defined build and deployment commands, ran the workflow and inspected the logs. I validated the application or deployed resource on AWS. I documented the conditions that cause a deployment and how failures are surfaced. The project output consisted of a GitHub Actions workflow that executes the defined AWS deployment steps and produces a validated target output. This approach enables deployment activity to be tracked alongside source changes. For Flexytie, the business opportunity is less manual release work and quicker visibility of failures, with security dependent on credential and permission configuration. The workflow can support frequent application updates or infrastructure deployments from a repository. It makes deployment status visible to contributors and preserves execution logs for investigation.

## Evidence to add

- [ ] Sanitized architecture diagram
- [ ] Original configuration/scripts (where available)
- [ ] Screenshots with account IDs, secrets and IPs removed
- [ ] Validation steps and outcome
- [ ] Lessons learned

## Confidentiality

Do not upload credentials, access keys, real customer data, internal company files or unredacted cloud account information.
