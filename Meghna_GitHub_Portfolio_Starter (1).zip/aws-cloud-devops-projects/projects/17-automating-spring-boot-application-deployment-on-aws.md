# Project 17: Automating Spring Boot Application Deployment on AWS

**Project type:** Hands-on cloud/DevOps implementation

## Project summary

I automated a CI/CD pipeline for a Spring Boot application on AWS, connecting application packaging with deployment and runtime checks. I connected the Spring Boot repository to the chosen pipeline. I configured dependencies, build commands and any tests included in the project. I packaged the application in the artifact format actually used and deploy it to the AWS target. I checked service startup, logs and an application endpoint. I documented configuration requirements and distinguished build success from runtime success. The project output consisted of a Spring Boot application delivered through an AWS deployment workflow, with build evidence and a working endpoint. This approach enables more consistent delivery of Java application changes. The business opportunity is faster feedback and fewer manual deployment mistakes; measured release improvements require baseline and pipeline timing data. A repeatable Java delivery workflow can support application maintenance and incremental feature delivery. Separating build, deployment and runtime checks makes the release process easier to assess.

## Evidence to add

- [ ] Sanitized architecture diagram
- [ ] Original configuration/scripts (where available)
- [ ] Screenshots with account IDs, secrets and IPs removed
- [ ] Validation steps and outcome
- [ ] Lessons learned

## Confidentiality

Do not upload credentials, access keys, real customer data, internal company files or unredacted cloud account information.
