# Project 18: Highly Available Load Balanced Architecture Configured Through CLI

**Project type:** Hands-on cloud/DevOps implementation

## Project summary

I configured a load balanced architecture through the command line to distribute incoming traffic among healthy service instances. I used the CLI to configure the load balancer, listeners and target membership supported by the environment. I deployed the service on multiple targets and configured health checks. I recorded the actual zone and instance arrangement. The project output consisted of a shared endpoint routing requests to healthy targets. A resilience result requires evidence of continued service during a controlled target failure; multiple targets alone do not prove full high availability. This approach enables traffic distribution and reduces dependence on one service instance. For Flexytie, the business opportunity is improved continuity under target failure, subject to the complete architecture and test results. Traffic distribution can support services that need multiple active instances. Health based routing allows healthy targets to receive traffic when another target becomes unavailable, within the limits of the configured architecture.

## Evidence to add

- [ ] Sanitized architecture diagram
- [ ] Original configuration/scripts (where available)
- [ ] Screenshots with account IDs, secrets and IPs removed
- [ ] Validation steps and outcome
- [ ] Lessons learned

## Confidentiality

Do not upload credentials, access keys, real customer data, internal company files or unredacted cloud account information.
