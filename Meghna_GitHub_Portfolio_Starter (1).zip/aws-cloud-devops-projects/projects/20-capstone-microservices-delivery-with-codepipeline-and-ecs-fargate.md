# Project 20: Capstone Microservices Delivery with CodePipeline and ECS Fargate

**Project type:** Hands-on cloud/DevOps implementation

## Project summary

I completed a capstone implementation of microservices delivery using AWS CodePipeline and Amazon ECS Fargate, connecting pipeline execution with managed container deployment. I prepared the service repositories and container definitions. I configured image builds and the registry used in the project. I defined Fargate task and service settings, networking and runtime permissions. I connected source, build and deployment stages in CodePipeline. I ran the pipeline, inspected task startup and validated the service endpoints or frontend to backend interaction. The project output consisted of Containerized microservices running as ECS Fargate tasks and delivered through CodePipeline. The project connected pipeline execution with the container runtime and application access. This approach enables container delivery without administering the underlying task servers. For Flexytie, the business opportunity is reduced server maintenance and a consistent deployment process; independent scaling and zero downtime require their own configuration and tests. The capstone provides a managed container delivery pattern for applications with multiple services. Teams can build on it with service specific scaling, deployment policies and operational controls as requirements grow.

## Evidence to add

- [ ] Sanitized architecture diagram
- [ ] Original configuration/scripts (where available)
- [ ] Screenshots with account IDs, secrets and IPs removed
- [ ] Validation steps and outcome
- [ ] Lessons learned

## Confidentiality

Do not upload credentials, access keys, real customer data, internal company files or unredacted cloud account information.
