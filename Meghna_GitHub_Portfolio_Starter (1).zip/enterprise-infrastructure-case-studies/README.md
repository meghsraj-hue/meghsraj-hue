# Enterprise Infrastructure — Anonymized Case Studies

These are generalized summaries of enterprise infrastructure work, not source-code repositories or copies of internal ICICI Bank materials.

## 1. Enterprise backup reliability and disaster recovery

**Context:** Business-critical banking applications and data protection across server, database, storage and network environments.  
**Role:** Coordinated infrastructure and vendor stakeholders, backup troubleshooting, implementation planning, recovery readiness and operational improvements.  
**Technologies:** Veritas NetBackup, EMC Data Domain, Oracle databases, Linux/Unix and enterprise storage.  
**Reported outcome:** Improved backup success rates from approximately 65% to 99%.

## 2. Oracle enterprise monitoring and operational visibility

**Context:** Proactive monitoring and capacity planning for a large Oracle database estate.  
**Role:** Led Oracle Enterprise Manager monitoring rollout, alerting and cross-team issue management.  
**Reported scale:** 300+ production databases.

## 3. Cross-functional infrastructure modernization

**Context:** Coordinating infrastructure readiness, changes, testing, vendor dependencies and production releases.  
**Role:** Technical program management, risk/dependency tracking, stakeholder communication, QA/UAT and operational handoffs.

**Confidentiality:** No real architecture, internal diagrams, system names, IP addresses, tickets, customer data or proprietary runbooks are published here.
