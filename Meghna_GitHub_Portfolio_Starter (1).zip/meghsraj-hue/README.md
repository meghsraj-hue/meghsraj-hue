# Hi, I'm Meghna Shah 👋

**Technical Program Manager | Enterprise Infrastructure | Cloud & DevOps**

📍 Fremont, California · [LinkedIn](https://www.linkedin.com/in/meghna-shah9) · [Email](mailto:mpmota81@gmail.com)

I bring **17 years of enterprise IT experience** across technical program delivery, data center infrastructure, production operations, Oracle database monitoring, storage, backup and disaster recovery. At ICICI Bank, I coordinated cross-functional engineering, infrastructure, QA, operations and vendor teams on business-critical technology initiatives.

I have also completed **20 hands-on AWS and DevOps projects** to extend my infrastructure background into cloud provisioning, CI/CD, containers, monitoring and automation. This GitHub portfolio documents those learning implementations alongside **anonymized, non-proprietary enterprise infrastructure and program management case studies**.

## Technologies & platforms

- **Cloud:** AWS EC2, VPC, IAM, S3, RDS, Lambda, EBS, CloudWatch, ECS/ECR, EKS, CodePipeline; Azure load balancing
- **DevOps:** Terraform, Jenkins, Docker, Ansible, Git/GitHub, GitHub Actions, CI/CD
- **Enterprise IT:** Oracle Database, Oracle Enterprise Manager, Linux/Unix, EMC Data Domain, Veritas NetBackup, server/storage/network operations, backup and disaster recovery
- **Delivery:** Agile/Scrum, SAFe, SDLC, Jira, Confluence, QA/UAT, release governance, RAID, stakeholder and vendor coordination

## Featured portfolio

| Portfolio | What you'll find |
|---|---|
| [AWS & DevOps — 20 projects](https://github.com/meghsraj-hue/aws-cloud-devops-projects) | Project index, cloud architectures, automation and deployment write-ups |
| [Enterprise infrastructure case studies](https://github.com/meghsraj-hue/enterprise-infrastructure-case-studies) | Sanitized descriptions of monitoring, backup, storage and infrastructure delivery |
| [Technical program management toolkit](https://github.com/meghsraj-hue/technical-program-management) | Sample RAID, release-readiness and UAT coordination templates |

## Certifications & professional development

Certified ScrumMaster (CSM) · Certified Scrum Product Owner (CSPO) · Advanced Certified ScrumMaster (A-CSM) · Advanced Certified Scrum Product Owner (A-CSPO) · SAFe 6.01 Certified · AI for Scrum Masters · AI for Product Owners · Get Started with AI Prompt Engineering · AI for Product Discovery and Strategy · Cloud Computing & DevOps program (Purdue University / Simplilearn)

> **Portfolio note:** Cloud projects are hands-on learning implementations. Enterprise examples are generalized and do not expose confidential employer systems, production configurations or customer data.
